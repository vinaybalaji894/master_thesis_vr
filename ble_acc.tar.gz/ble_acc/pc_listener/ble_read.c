#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <glib.h>
#include "gattlib.h"

#define NUS_CHARACTERISTIC_TX_UUID	"6e400003-b5a3-f393-e0a9-e50e24dcca9e"

gatt_connection_t* m_connection;

void notification_cb(const uuid_t* uuid, const uint8_t* data, size_t data_length, void* user_data)
{
	printf
}

static void usage(char *argv[]) {
	printf("%s <device_address>\n", argv[0]);
}

void int_handler(int dummy) {
	gattlib_disconnect(m_connection);
	exit(0);
}

int main(int argc, char *argv[]) {
	//	char input[256];
	//	char* input_ptr;
	int  ret;//, total_length, length = 0;
	uuid_t nus_characteristic_tx_uuid;
	uuid_t nus_characteristic_rx_uuid;

	if (argc != 2) {
		usage(argv);
		return 1;
	}

	m_connection = gattlib_connect(NULL, argv[1], BDADDR_LE_RANDOM, BT_SEC_LOW, 0, 0);
	if (m_connection == NULL) {
		fprintf(stderr, "Fail to connect to the bluetooth device.\n");
		return 1;
	}

	// Convert characteristics to their respective UUIDs
	ret = gattlib_string_to_uuid(NUS_CHARACTERISTIC_TX_UUID, strlen(NUS_CHARACTERISTIC_TX_UUID) + 1, &nus_characteristic_tx_uuid);
	if (ret) {
		fprintf(stderr, "Fail to convert characteristic TX to UUID.\n");
		return 1;
	}
	ret = gattlib_string_to_uuid(NUS_CHARACTERISTIC_RX_UUID, strlen(NUS_CHARACTERISTIC_RX_UUID) + 1, &nus_characteristic_rx_uuid);
	if (ret) {
		fprintf(stderr, "Fail to convert characteristic RX to UUID.\n");
		return 1;
	}


	printf("status notification start: %d\n", gattlib_notification_start(m_connection, &nus_characteristic_rx_uuid));
	// Register notification handler
	gattlib_register_notification(m_connection, notification_cb, NULL);

	printf("status notification start: %d\n", gattlib_notification_start(m_connection, &nus_characteristic_rx_uuid));

	// Register handler to catch Ctrl+C
	signal(SIGINT, int_handler);

	GMainLoop *loop = g_main_loop_new(NULL, 0);
	g_main_loop_run(loop);

	g_main_loop_unref(loop);
	gattlib_disconnect(m_connection);
	puts("Done");
	return 0;


}
