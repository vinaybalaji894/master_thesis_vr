#ifndef BLE_H_
#define BLE_H_

void ble_init(void);
void uart_init(void);
void ble_task(void);

#endif /* BLE_H_ */
