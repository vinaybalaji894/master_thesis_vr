/*!
* @brief Component name:	MAIN
*
* Entry code for TWI/Accelerometer Driver.
* Initialise and configure the TWI, LIS2DH12 and UART.
* DWM1001 drivers for use with DEV board.
* Uses a re-directed STDIO for printf, through UART.
*
* @file main.c
*/

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "nordic_common.h"
#include "nrf.h"
#include "nrf_delay.h"
#include "app_timer.h"
#include "twi.h"
#include "LIS2DH12.h"
#include "bsp.h"
#include "boards.h"
#include "ble_uart.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#define STATUS_LED_PERIOD	APP_TIMER_TICKS(1000)
APP_TIMER_DEF(status_led);

static void status_led_timer_handler(void * p_context)
{
	   UNUSED_PARAMETER(p_context);
	   bsp_board_led_invert(GREEN_LED);
}

static void timers_init()
{
    ret_code_t err_code;

    // Initialize timer module.
    err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);

    // Create timers
    err_code = app_timer_create(&status_led, APP_TIMER_MODE_REPEATED, status_led_timer_handler);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_start(status_led, STATUS_LED_PERIOD, NULL);
    APP_ERROR_CHECK(err_code);
}

static void log_init(void)
{
    ret_code_t err_code = NRF_LOG_INIT(NULL);
    APP_ERROR_CHECK(err_code);

    NRF_LOG_DEFAULT_BACKENDS_INIT();
}

int main(void)
{
	timers_init();
	uart_init();
	log_init();
	bsp_board_leds_init();

	ble_init();

	twi_init();
	LIS2_init();
	
	while (true) {
	//	LIS2_task();
		ble_task();
	//	__WFE();
	}
}
