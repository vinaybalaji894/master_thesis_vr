void twi_init (void);
void twi_write (uint8_t address, uint8_t pdata);
void twi_read (uint8_t address, uint8_t *pdata, uint8_t length);
