#include <stdio.h>
#include "app_util_platform.h"
#include "app_error.h"
#include "nrf_drv_twi.h"
#include "nrf_drv_gpiote.h"
#include "boards.h"
#include "twi.h"

// DWM1001 module has LIS2DH12 pin SDO/SA0 pin pulled high,
// ensuring the on-chip bus address register
// (default setting 0001100x) is set to 00011001.
#define	LIS2DH_ADD			0x19

// Local symbolic constants
#define TWI_INSTANCE_ID		0

// TWI instance structure for Nordic nrf device driver.
static const nrf_drv_twi_t m_twi = NRF_DRV_TWI_INSTANCE(TWI_INSTANCE_ID);

// Semaphore: true if TWI transfer operation has completed
static volatile bool transfer_done = false;

static ret_code_t twi_err_code;

static void twi_event_handler(nrf_drv_twi_evt_t const * p_event, void * p_context)
{
	switch (p_event->type)
	{
	case NRF_DRV_TWI_EVT_DONE:
	{
		switch (p_event->xfer_desc.type)
		{
		case NRF_DRV_TWI_XFER_TX:
		case NRF_DRV_TWI_XFER_RX:
		{
			transfer_done = true;
			break;
		}
		default:
			//printf("unknown xfer_desc.type: %x\n", p_event->xfer_desc.type);
			break;
		}
		break;
	}
	default:
		//printf("Unknown event type: %x\n", p_event->type);
		break;
	}
}

/*
 * void vWaitForEvent(void)
 *
 * For single-threaded systems, this function blocks until the
 * TWI transfer complete interrupt occurs. Whilst waiting, the
 * CPU enters low-power sleep mode.
 *
 * For multi-threaded (RTOS) builds, this function would suspend
 * the thread until the transfer complete event occurs.
 */

static void wait_for_twi_event(void)
{
	do
	{
		__WFE();
	}
	while (! transfer_done);
}

void twi_write (uint8_t address, uint8_t data)
{
	uint8_t buffer[2];
	buffer[0] = address;
	buffer[1] = data;

	transfer_done = false;
	twi_err_code = nrf_drv_twi_tx(&m_twi, LIS2DH_ADD, buffer, 2, false);
	APP_ERROR_CHECK(twi_err_code);

	wait_for_twi_event();
}

void twi_read (uint8_t address, uint8_t *buffer, uint8_t length)
{
//	bsp_board_led_on(RED_LED);

	transfer_done = false;
	twi_err_code = nrf_drv_twi_tx(&m_twi, LIS2DH_ADD, &address, 1, false);
	APP_ERROR_CHECK(twi_err_code);

	wait_for_twi_event();

	transfer_done = false;
	twi_err_code = nrf_drv_twi_rx(&m_twi, LIS2DH_ADD, buffer, length);
	APP_ERROR_CHECK(twi_err_code);

	wait_for_twi_event();

//	bsp_board_led_off(RED_LED);
}

void twi_init (void)
{
	const nrf_drv_twi_config_t twi_config = {
			.scl                = TWI_SCL,
			.sda                = TWI_SDA,
			.frequency          = NRF_TWI_FREQ_400K,
			.interrupt_priority = APP_IRQ_PRIORITY_LOW,
			.clear_bus_init     = false
	};

	twi_err_code = nrf_drv_twi_init(&m_twi, &twi_config, twi_event_handler, NULL);
	APP_ERROR_CHECK(twi_err_code);

	nrf_drv_twi_enable(&m_twi);
}

