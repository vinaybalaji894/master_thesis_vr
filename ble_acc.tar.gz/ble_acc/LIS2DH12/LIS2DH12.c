#include <stdio.h>
#include "app_util_platform.h"
#include "app_error.h"
#include "nrf_drv_gpiote.h"
#include "nrf_delay.h"
#include "LIS2DH12.h"

#include "twi.h"
#include "LIS2DH12registers.h"
#include "bsp.h"
#include "boards.h"

volatile bool int_bit = false;

void LIS2_task (void)
{
	uint8_t bytes[10];

	while(true)
	{
		if (int_bit)
		{
			bsp_board_led_on(BLUE_LED);

//			twi_read(0xa7, bytes, 7);
//			printf("%2x   %6d|%6d|%6d \n", bytes[0], (int16_t)( bytes[1] | (bytes[2]<<8)), (int16_t)( bytes[3] | (bytes[4]<<8)), (int16_t)( bytes[5] | (bytes[6]<<8)));
//			uint8_t byte;
//			twi_read(0x2f, &byte, 1);
//			printf("%2x\n", byte);//, bytes[1], bytes[2], bytes[3]);
			twi_read(0xa8, bytes, 6);
			printf("%6d %6d %6d\n", (int16_t)( bytes[0] | (bytes[1]<<8)), (int16_t)( bytes[2] | (bytes[3]<<8)), (int16_t)( bytes[4] | (bytes[5]<<8)));

			int_bit = false;
			bsp_board_led_off(BLUE_LED);
		}
//		bsp_board_led_invert(RED_LED);
		__WFE();
	}
}

static void interrupt_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action)
{
	int_bit = true;
}

static void enable_interrupt (void)
{
	ret_code_t err_code;

	if (nrf_drv_gpiote_is_init())
		printf("nrf_drv_gpiote_init already installed\n");
	else
		nrf_drv_gpiote_init();

	// input pin, +ve edge interrupt, no pull-up
	nrf_drv_gpiote_in_config_t in_config = GPIOTE_CONFIG_IN_SENSE_LOTOHI(true);
	in_config.pull = NRF_GPIO_PIN_NOPULL;

	// Link this pin interrupt source to its interrupt handler
	err_code = nrf_drv_gpiote_in_init(LIS2DH12_INT_PIN, &in_config, interrupt_handler);
	APP_ERROR_CHECK(err_code);

	nrf_drv_gpiote_in_event_enable(LIS2DH12_INT_PIN, true);
}

void LIS2_init (void)
{

	// Put device into power-down in case there was no power cycle
	// Set the ODR value to put device into power-down mode.


	twi_write(CTRL_REG1, ODR_PDOWN);
	nrf_delay_ms(10);

	// reboot memory & wait for boot
	twi_write(CTRL_REG5, BOOT);
	nrf_delay_ms(20);

	// Set the scale to 4G
	twi_write(CTRL_REG4, FS_4G);

	// Enable X,Y,Z sensors and set max sample rate
	twi_write(CTRL_REG1, (ODR_400Hz | X_EN | Y_EN | Z_EN));

	// Enable MCU interrupts from INT1 pin
	enable_interrupt();

	// enable xyzda interrupt
	twi_write(CTRL_REG3, 0x10);

	// Enable FIFO
	twi_write(CTRL_REG5, FIFO_EN);

	// Set BYPASS mode to reset the FIFO
	twi_write(FIFO_CTRL_REG, BYPASS);
	uint8_t u8Dummy;
	twi_read(FIFO_SRC_REG, &u8Dummy, 1);
}
