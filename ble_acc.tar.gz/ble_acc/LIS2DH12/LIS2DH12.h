extern volatile bool int_bit;

// Public interface functions
void 	LIS2_init					(void);
void 	LIS2_task					(void);
void	LIS2_EnableWakeUpDetect		(void);
void	LIS2_EnableInactivityDetect	(void);
void 	LIS2_EnableFifoSampling		(void);
bool	LIS2_InterruptOccurred 		(void);
uint8_t	LIS2_EventStatus 			(void);

// Threshold event status bits
#define	XLIE			0x01
#define	XHIE			0x02
#define	YLIE			0x04
#define	YHIE			0x08
#define	ZLIE			0x10
#define	ZHIE			0x20

