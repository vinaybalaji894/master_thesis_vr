import turtle
import time
from random import randint
import serial
import subprocess
import sys
ser=serial.Serial('/dev/ttyACM0')
ser.baudrate=115200
#ser = open('expt_c_3.txt', 'r')

turtle.title("Offside Detection")
turtle.screensize(366,508)
turtle.setup (width=366, height=528, startx=0, starty=0)
turtle.bgpic("Drawing.png")

fred=turtle.Turtle()
alex=turtle.Turtle()
tom=turtle.Turtle()
kevin=turtle.Turtle()

fred.color('#00D201','blue')
kevin.color('#00D201', 'blue')
alex.color('#00D201', 'red')
tom.color('#00D201', 'red')

fred.shape("square")
alex.shape("square")
tom.shape("square")
kevin.shape("square")

fred.resizemode("user")
fred.shapesize(0.5, 0.5, 0.5)
alex.resizemode("user")
alex.shapesize(0.5, 0.5, 0.5)
kevin.resizemode("user")
kevin.shapesize(0.5, 0.5, 0.5)
tom.resizemode("user")
tom.shapesize(0.5, 0.5, 0.5)

input_low_x=0
input_high_x=3     # change to 16
output_low_x=-160
output_high_x=160

input_low_y=0
input_high_y=4 # change to 24
output_low_y=-240
output_high_y=240
def scale_x(x):
	if x<3:
		rx= (((x-input_low_x)/(input_high_x - input_low_x))*(output_high_x - output_low_x)) +output_low_x
		#global prev_x
		#prev_x=rx
		return int(rx)
	else:
		return 165

def scale_y(y):
	if y<4.1:
		ry= (((y-input_low_y)/(input_high_y - input_low_y))*(output_high_y - output_low_y)) +output_low_y
		#global prev_y
		#prev_y=ry
		return int(ry)
	else:
		return 250


'''
while (1):
	r1=str(ser.readline())
	r2=r1[6:21]
	try:
		if r2.startswith('CDB3'):
			x1=int(float(r2[5:9])*107.0)
			y1=int(float(r2[10:14])*119.0)
			alex.setpos(x1,y1)
			#time.sleep(2)
			print(x1)
			print(y1)
			print('1')

		elif r2.startswith('DA2A'):
			x2=int(float(r2[5:9])*107.0)
			y2=int(float(r2[10:14])*119.0)
			fred.setpos(x2,y2)
			#time.sleep(2)
			print(x2)
			print(y2)
			print('2')
		elif r2.startswith('D7A8'):
			x3=int(float(r2[5:9])*107.0)
			y3=int(float(r2[10:14])*119.0)
			kevin.setpos(x3,y3)
			#time.sleep(2)
			print(x3)
			print(y3)
			#print(r2[10:14])
			print('3')
		elif r2.startswith('C1A3'):
			x4=int(float(r2[5:9])*107.0)
			y4=int(float(r2[10:14])*119.0)
			tom.setpos(x4,y4)
			#time.sleep(2)
			print(x4)
			print(y4)
			print('4')
	except RuntimeError:
		print("Broke")
'''
'''
while 1:

	alex.setpos(160,240)
	time.sleep(2)
	fred.setpos(160,-240)
	time.sleep(2)
	tom.setpos(-160,240)
	kevin.setpos(-160,-240)
'''

i=0
prev_x1=0
prev_y1=0
prev_x2=0
prev_y2=0
prev_x3=0
prev_y3=0
prev_x4=0
prev_y4=0
while (1):
	r1=str(ser.readline())
	r2=r1[6:21]
	i=i+1
	print(i)
	try:
		if r2.startswith('CDB3'):
			x1=scale_x(float(r2[5:9]))
			y1=scale_y(float(r2[10:14]))
			if x1>164 or y1>245:
					alex.setpos(prev_x1,prev_y1)
					print('ty')
					continue
			alex.setpos(x1,y1)
			global prev_x1
			prev_x1 = x1
			global prev_y1
			prev_y1 = y1
			#time.sleep(2)
			print(x1)
			print(y1)


		elif r2.startswith('DA2A'):
			x2=scale_x(float(r2[5:9]))
			y2=scale_y(float(r2[10:14]))


			if x2>164 or y2>245:
					fred.setpos(prev_x2,prev_y2)
					print('ty')
					continue
			fred.setpos(x2,y2)
			global prev_x2
			prev_x2 = x2
			global prev_y2
			prev_y2 = y2
			#time.sleep(2)
			print(x2)
			print(y2)

		elif r2.startswith('D7A8'):
			x3=scale_x(float(r2[5:9]))
			y3=scale_y(float(r2[10:14]))


			if x3>164 or y3>245:
					kevin.setpos(prev_x3,prev_y3)
					print('ty')
					continue
			kevin.setpos(x3,y3)
			global prev_x3
			prev_x3 = x3
			global prev_y3
			prev_y3 = y3

			#time.sleep(2)
			print(x3)
			print(y3)
			#print(r2[10:14])

		elif r2.startswith('C1A3'):
			x4=scale_x(float(r2[5:9]))
			y4=scale_y(float(r2[10:14]))


			if x4>164 or y4>245:
					tom.setpos(prev_x4,prev_y4)
					print('ty')
					continue
			tom.setpos(x4,y4)
			global prev_x4
			prev_x4 = x4
			global prev_y4
			prev_y4 = y4

			#time.sleep(2)
			print(x4)
			print(y4)

	except RuntimeError:
		print("Broke")

#ser.close()


'''
f1=input()
f2=scale_y(float(f1))
print(f2)
'''

alex.done()
turtle.done()
