import serial
import subprocess
import sys
ser=serial.Serial('/dev/ttyACM0')
ser.baudrate=115200


while (1):
	r1=ser.readline()
	#r2=r1[6:21]
	print(r1)
	'''
	if r2.startswith('CDB3'):
		print(r2[5:9])
		print(r2[10:14])
		print(r2)

	elif r2.startswith('DA2A'):
		print(r2[5:9])
		print(r2[10:14])
		print(r2)
		#print(r1)
	elif r2.startswith('D7A8'):
		print(r2[5:9])
		print(r2[10:14])
		print(r2)
	elif r2.startswith('C1A3'):
		print(r2[5:9])
		print(r2[10:14])
		print(r2)
		#print(r1)
	'''
