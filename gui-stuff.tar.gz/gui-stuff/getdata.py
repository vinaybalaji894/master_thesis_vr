import serial
f1=serial.Serial('/dev/ttyACM0')

while 1:
    s=f1.readline()
    print(s)
    delay(1000)
