import numpy as np
import matplotlib.pyplot as plt
import re


#r1=data.split(",")[0].strip()
#print r1


'''
i=0
while 1:
    i=i+1
    r1=str(ser.readline())
    r2=r1.split("  ")[0].strip()
    y=int(r2)
    plt.scatter(i, y)
    plt.pause(0.05)

plt.show()
ser.close()
'''

import serial

from drawnow import *
ser = open('sam_acc.txt', 'r')
values = []

plt.ion()
cnt=0

#serialArduino = serial.Serial('/dev/ttyACM0', 19200)

def plotValues():
    plt.title('Wireless Acc')
    plt.grid(True)
    plt.ylabel('Values')
    plt.plot(values, 'rx-', label='values')
    plt.legend(loc='upper right')

#pre-load dummy data
for i in range(0,26):
    values.append(0)
i=0
while True:
    #while (serialArduino.inWaiting()==0):
        #pass
    r1=str(ser.readline())
    i=i+1
    print i
    r2=r1.split("  ")[0].strip()
    valueRead = r2

    #check if valid value can be casted
    try:
        valueInInt = int(valueRead)
        #print(valueInInt)

        values.append(valueInInt)
        values.pop(0)
        drawnow(plotValues)
            
    except ValueError:
        print "Invalid! cannot cast"
