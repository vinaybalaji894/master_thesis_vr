#!/bin/bash
sleep 5
var="$(ps axf | grep minicom | grep -v grep| awk '{print $1}')" 
sleep 10
kill -9 $var
sleep 5
set -x
#reset
