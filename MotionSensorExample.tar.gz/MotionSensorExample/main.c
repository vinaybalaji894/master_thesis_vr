#include <unistd.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "MotionSensor.h"
#include <signal.h>
#include <stdbool.h>
#include <errno.h>
#include <stdint.h>
#include <wiringPiI2C.h>
#include <wiringSerial.h>

#include <errno.h>

#include <wiringPi.h>
//using namespace std;




#define delay_ms(a) usleep(a*1000)

volatile sig_atomic_t print_flag = false;


void handle_alarm( int sig ) {
    print_flag = true;
}


//int timer_create(clockid_t clockid, struct sigevent *restrict evp,timer_t *restrict timerid);

//using namespace std;

int main() {


  long int megh=0;
  //long int deca=0;
  //uint8_t fd;
  //int  result;
  //uint8_t xl,xh,yl,yh,zl,zh,cl,ch;
  //int16_t x,y,z,fifo;
  //float xtotal,ytotal,ztotal;
  //Setting up the file handling service

  //Waking up the sensor
  //wiringPiI2CWriteReg8 (fd, 0x6B, 0);
  //Write Configuration to sensor
  //wiringPiI2CWriteReg8 (fd, 28, 8);
  //useconds_t h;
  signal( SIGALRM, handle_alarm ); // Install handler first,
  //// before scheduling it to be called.
  //alarm(5);
  time_t rawtime;
  struct tm * timeinfo;
  int serial_port ;
  char dat;
  if ((serial_port = serialOpen ("/dev/ttyS0", 115200)) < 0)	/* open serial port */
  {
    printf ("Unable to open serial device\n") ;
    return 1 ;
  }

  if (wiringPiSetup () == -1)					/* initializes wiringPi setup */
  {
    printf ("Unable to start wiringPi\n") ;
    return 1 ;
  }
	ms_open();
  ualarm( (useconds_t)(10000), (useconds_t)(10000));
	while(1){
		//delay_ms(1);
    //fd = wiringPiI2CSetup(0x1e);




    ms_update();


    time(&rawtime );
   timeinfo = localtime(&rawtime);

   printf("yaw= %4.4f\tpitch= %4.4f\troll= %4.4f\tcount=%d\taccX= %4.4f\taccY= %4.4f\taccZ= %4.4f\t%s",
    ypr[YAW], ypr[PITCH],
    ypr[ROLL],count,accel[0],accel[1],accel[2],asctime(timeinfo));

    ++megh;


    if (megh==10 ) {
      do{
       dat = serialGetchar (serial_port);		/* receive character serially*/
        printf ("%c", dat) ;
       fflush (stdout) ;
     }while(dat!='\n');



      ms_compass();
      printf("mx=%4.4f\tmy=%4.4f\tmz=%4.4f\t%s",compass[0],compass[1],compass[2],asctime(timeinfo));
      megh = 0;
    }




/*
     printf("yaw= %4.4f\tpitch= %4.4f\troll= %4.4f\tcount=%d\taccX= %4.4f\taccY= %4.4f\taccZ= %4.4f\tmx=%4.4f\tmy=%4.4f\tmz=%4.4f\t%s",
      ypr[YAW], ypr[PITCH],
      ypr[ROLL],count,accel[0],accel[1],accel[2],compass[0],compass[1],compass[2],asctime(timeinfo));
*/
  }

/*
ualarm( (useconds_t)(5000), (useconds_t)(5000));

  while(1){
  //std::time_t result = std::time(nullptr);
  time(&rawtime );
 timeinfo = localtime(&rawtime);
      if ( print_flag ) {

        x=0;
        y=0;
        z=0;
        xh = wiringPiI2CReadReg8(fd,59);
        xl = wiringPiI2CReadReg8(fd,60);
        yh = wiringPiI2CReadReg8(fd,61);
        yl = wiringPiI2CReadReg8(fd,62);
        zh = wiringPiI2CReadReg8(fd,63);
        zl = wiringPiI2CReadReg8(fd,64);
        x=(xl|xh<<8);
        y=(yl|yh<<8);
        z=(zl|zh<<8);

         xtotal=((x*0.12207)/1000.0)*9.80665;
         ytotal=((y*0.12207)/1000.0)*9.80665;
        ztotal=((z*0.12207)/1000.0)*9.80665;


        //printf( "Hello\n" );
        printf("accX= %4.4f\taccY= %4.4f\taccZ= %4.4f\t%s",xtotal,ytotal,ztotal,asctime(timeinfo));
          //std::cout<<"1st "<<std::asctime(std::localtime(&result));
          print_flag = false;
          ++gyro;
          ++deca;
          //printf("%ld\n",count );
          //ualarm( (useconds_t)( 5 * 100 * 1000 ), 0 );
         }
         if (gyro==2 ) {

           ms_update();
          printf("yaw= %4.4f\tpitch= %4.4f\troll= %4.4f\tcount=%d\taccX= %4.4f\taccY= %4.4f\taccZ= %4.4f\t%s",
          ypr[YAW], ypr[PITCH],
          ypr[ROLL],count,accel[0],accel[1],accel[2],asctime(timeinfo));


             //std::cout<<"2nd "<<std::asctime(std::localtime(&result));
             //print_flag = false;
             gyro = 0;
             //printf("%ld\n",count );
             //ualarm( (useconds_t)( 5 * 100 * 1000 ), 0 );


            }

            if (deca==20 ) {

                //std::cout<<"3rd "<<std::asctime(std::localtime(&result));
                //print_flag = false;
                deca = 0;
                //printf("%ld\n",count );
                //ualarm( (useconds_t)( 5 * 100 * 1000 ), 0 );
               }


      }


*/



	return 0;
}
