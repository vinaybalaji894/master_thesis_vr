#!/bin/bash
set +x
echo "23" > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio23/direction
echo "0" > /sys/class/gpio/gpio23/value
echo "1" > /sys/class/gpio/gpio23/value
./killer.sh &
minicom -D /dev/ttyS0 -b 115200 -S /home/pi/ministart.txt
reset
./mstest
