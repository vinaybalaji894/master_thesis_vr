import serial
import subprocess
import sys
#ser=serial.Serial('/dev/ttyACM0')
#ser.baudrate=115200
ser=open('01_07_c_4bt2_iii.txt','r')

for l1 in ser:
    dist_list=[]
    sline=l1.split(',')
    if('POS' in l1):	
	i=l1.index('POS')
        print(l1[i:-1])

    del dist_list[:]

'''
for l2 in ser:
    dist_list=[]
    sline=l2.split(',')
    if('CDB3' in l2):
        print(l2.strip())

    del dist_list[:]
'''
'''
for line in ser:
    dist_list=[]
    sline=line.split(',')
    if('4191' in line):
        print(line)

    del dist_list[:]
'''
ser.close()
