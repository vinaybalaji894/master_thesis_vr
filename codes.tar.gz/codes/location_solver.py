import serial
import numpy as np
from math import pow
from math import sqrt
ser = open('01_07_c_4bt2_iii.txt', 'r')
# Based on an algorithm described by Paul Bourke:
# https://web.archive.org/web/20060911063359/http://local.wasp.uwa.edu.au/~pbourke/geometry/2circle/
def Intersection(P0, P1, r0, r1):
  if type(P0) != Vector2 or type(P1) != Vector2:
    raise TypeError("P0 and P1 must be vectors")

  # equation 1
  offset = P1 - P0
  d = offset.magnitude()

  # equation 2: simple cases
  if d > (r0 + r1):
    # no collision
    return False
  elif d == 0 or d < abs(r0 - r1):
    # full containment
    return True

  # equation 3
  a = (r0**2 - r1**2 + d**2) / (2 * d)

  # equation 4
  h = sqrt(abs(r0**2 - a**2))

  # equation 5
  P2 = P0 + a * (P1 - P0) / d

  # equation 6
  if (d == r0 + r1):
    return [P2]

  # equation 8
  alpha_x = P2.x + h * (P1.y - P0.y) / d
  alpha_y = P2.y - h * (P1.x - P0.x) / d
  alpha = Vector2(alpha_x, alpha_y)

  # equation 9
  beta_x = P2.x - h * (P1.y - P0.y) / d
  beta_y = P2.y + h * (P1.x - P0.x) / d
  beta = Vector2(beta_x, beta_y)

  if alpha_x>0 and alpha_y>0:
      print("%f,%f" % (alpha_x,alpha_y))
  else:
      print("%f,%f" % (beta_x,beta_y))





# Simple 2D vector class.
# Based on work by @mcleonard on github:
# https://gist.github.com/mcleonard/5351452
class Vector2(object):
  def __init__(self, x, y):
    """Create a vector, e.g. v = Vector2(10, 15)"""
    self.x = x
    self.y = y

  def magnitude(self):
    """Returns the magnitude of this vector."""
    return sqrt(self.x**2 + self.y**2)

  def __add__(self, other):
    """Returns the vector addition of self and other."""
    newx = self.x + other.x
    newy = self.y + other.y
    return Vector2(newx, newy)

  def __sub__(self, other):
    """Returns the vector difference of self and other."""
    newx = self.x - other.x
    newy = self.y - other.y
    return Vector2(newx, newy)

  def __mul__(self, other):
    """Multiplies each component if other is a scalar"""
    if type (other) == type(1) or type(other) == type(1.0):
      return Vector2(self.x * other, self.y * other)
    else:
      raise NotImplementedError

  def __rmul__(self, other):
    return self.__mul__(other)

  def __div__(self, other):
    """Divides each component if other is a scalar"""
    if type (other) == type(1) or type(other) == type(1.0):
      return Vector2(self.x / other, self.y / other)
    else:
      raise NotImplementedError

  def __str__(self):
    """Returns this vector as a string of the form: (x, y)"""
    return "(%(x)d, %(y)d)" % { "x": self.x, "y": self.y }







def trilaterate(dlist):
    if dlist[4]==4:
        a = np.array([[32,0], [0,48]])
        C=float(dlist[0])**2-float(dlist[1])**2+256
        D=float(dlist[1])**2-float(dlist[2])**2+576
        b = np.array([C,D])
        x = np.linalg.solve(a, b)
        print("%f,%f" % (x[0],x[1]))


    elif dlist[4]==3:
        if dlist.index(-1)==0:
            a = np.array([[0,48], [-32,0]])
            C=float(dlist[1])**2-float(dlist[2])**2+576
            D=float(dlist[2])**2-float(dlist[3])**2-256
            b = np.array([C,D])
            x = np.linalg.solve(a, b)
            print("%f,%f" % (x[0],x[1]))

        elif dlist.index(-1)==1:
            a = np.array([[0,48], [32,0]])
            C=float(dlist[0])**2-float(dlist[3])**2+576
            D=float(dlist[3])**2-float(dlist[2])**2+256
            b = np.array([C,D])
            x = np.linalg.solve(a, b)
            print("%f,%f" % (x[0],x[1]))
        elif dlist.index(-1)==2:
            a = np.array([[0,-48], [32,0]])
            C=float(dlist[3])**2-float(dlist[0])**2-576
            D=float(dlist[0])**2-float(dlist[1])**2+256
            b = np.array([C,D])
            x = np.linalg.solve(a, b)
            print("%f,%f" % (x[0],x[1]))
        elif dlist.index(-1)==3:
            a = np.array([[32,0], [0,48]])
            C=float(dlist[0])**2-float(dlist[1])**2+256
            D=float(dlist[1])**2-float(dlist[2])**2+576
            b = np.array([C,D])
            x = np.linalg.solve(a, b)
            print("%f,%f" % (x[0],x[1]))
    elif dlist[4]==2:
        indices = [i for i, x in enumerate(dlist) if x == -1]
        #res=[]
        if indices==[2,3]:
            [Intersection(Vector2(0,0), Vector2(16, 0),dlist[0], dlist[1])]
            #print("2a")
            #del res[:]
        elif indices==[0,1]:
            [Intersection(Vector2(0,24), Vector2(16, 24),dlist[3], dlist[2])]
            #print("2b")
            #del res[:]
        elif indices==[1,2]:
            [Intersection(Vector2(0,0), Vector2(0, 24),dlist[0], dlist[3])]
            #print("2c")
            #del res[:]
        elif indices==[0,4]:
            [Intersection(Vector2(16,0), Vector2(16, 24),dlist[1], dlist[2])]
            #print("2d")
            #del res[:]
        elif indices==[0,2]:
            [Intersection(Vector2(16,0), Vector2(0, 24),dlist[1], dlist[3])]
            #print("2e")
            #del res[:]
        elif indices==[1,4]:
            [Intersection(Vector2(0,0), Vector2(16, 24),dlist[0], dlist[2])]
            #print("2f")
            #del res[:]

    #print(dlist)
i=0
for line in ser:
    dist_list=[]
    sline=line.split(',')
    #print(i)
    if('800D' in sline):
        dist_list.append(float(sline[sline.index('800D')+4]))
    else:
        dist_list.append(-1)
    if('0B32' in sline):
        dist_list.append(float(sline[sline.index('0B32')+4]))
    else:
        dist_list.append(-1)
    if('9B91' in sline):
        dist_list.append(float(sline[sline.index('9B91')+4]))
    else:
        dist_list.append(-1)
    if('1129' in sline):
        dist_list.append(float(sline[sline.index('1129')+4]))
    else:
        dist_list.append(-1)
    dist_list.append(int(sline[1]))
    trilaterate(dist_list)
    del dist_list[:]
    i=i+1
ser.close()
